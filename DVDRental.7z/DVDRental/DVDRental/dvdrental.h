#pragma once

#define TODAY 20231114


struct member
{
	int code;
	char name[256];
}mb[10];

struct product
	{
		int code;
		int serial;
		char name[256];
	}pd[10];
